# Website cá nhân nhiều kênh

Website tĩnh độc lập với AIFlow, Colab, SQLite và token. Nội dung hiện tại là **bản nháp**, theo lựa chọn của chủ sở hữu. Chưa triển khai lên hosting.

## Chạy bản nháp

Yêu cầu Node.js 20+ để build; không có dependency npm cần cài.

```powershell
cd D:\Project\AIFlow\public-site
node build.mjs
python -m http.server 5178 --bind 127.0.0.1 --directory dist/personal
```

Mở `http://127.0.0.1:5178`. Xem kênh khác bằng `--directory dist/stories`. Mỗi thư mục `dist/<channel>` là **gốc của một site riêng**; không host cả `dist` rồi dùng đường dẫn con, vì link nội bộ bắt đầu từ `/`.

Build một kênh:

```powershell
node build.mjs stories
```

Build thay thế thư mục đầu ra của kênh được chọn, loại bỏ trang/ảnh cũ đã bỏ khỏi cấu hình. Không sửa file trong `dist`; chúng sẽ bị tạo lại.

## Thay nội dung / thêm kênh

Sửa `channels.json`. Hiện có `personal` (tiếng Việt) và `stories` (tiếng Anh). Sao chép cấu hình một kênh để thêm kênh mới, đặt khóa dạng `pet-art` hoặc `my-channel`.

| Trường | Cách dùng |
|---|---|
| `name`, `headline`, `description` | Tên hiển thị và giới thiệu trên trang chủ |
| `about` | Giới thiệu cá nhân/thương hiệu; không cần sửa code |
| `language` | `vi` hoặc `en`, đổi nhãn điều hướng tương ứng |
| `draft` | Giữ `true` trong lúc soạn; site có nhãn nháp và `noindex,nofollow` |
| `siteUrl` | Để trống khi xem local; HTTPS origin của domain/hosting khi công khai |
| `email` | Để trống nếu chưa muốn công khai; không tạo form gửi mail giả |
| `links` | Mảng `{ "label": "YouTube", "url": "https://..." }` |
| `projects`, `products`, `articles` | Các danh sách nội dung mở rộng theo mẫu bên dưới |

Ví dụ một mục nội dung để tự điền, không phải portfolio đã có:

```json
{
  "slug": "ten-du-an",
  "title": "Tên dự án thật",
  "summary": "Mô tả ngắn công việc đã thực hiện.",
  "body": "Đoạn nội dung thứ nhất.\n\nĐoạn thứ hai.",
  "label": "Chân dung thú cưng",
  "approved": false,
  "publicConsent": false
}
```

Mỗi mục sinh một trang chi tiết. `body` là văn bản, ngăn đoạn bằng dòng trống; HTML được escape. Có thể thêm `url` và `linkLabel` cho đường dẫn HTTPS bên ngoài.

Ảnh chỉ được thêm sau khi chủ sở hữu duyệt và cho phép công khai:

1. Lấy file phù hợp từ **ZIP đã duyệt** trong AIFlow. Không tự lấy ảnh khách hàng làm portfolio.
2. Chép riêng file được phép vào `public-site/assets/`, ví dụ `assets/cat-watercolor.jpg`.
3. Thêm `image`, `alt`, đặt `approved: true`, `publicConsent: true` cho mục đó.
4. Build lại. Builder chỉ nhận PNG/JPEG/WebP trong thư mục assets, không sao chép cả thư mục storage của AIFlow.

Hai ngách dùng cùng cấu trúc: portrait trong `products`/`projects`; tập video trong `projects` với `url` tới video bạn đã đăng. Ngách mới chỉ cần thêm nội dung hoặc thêm kênh. Không có chức năng thanh toán hoặc tự đăng mạng xã hội.

## Domain / công khai sau này

Khi đã hoàn thiện thông tin và đồng ý công khai, đặt `draft: false`, thêm `siteUrl`, giới thiệu và email/link thật. Mọi mục nội dung phải có `approved` và `publicConsent`. Build sẽ chặn cấu hình thiếu những điều kiện này.

Có thể ghi đè domain khi build một kênh:

```powershell
$env:SITE_URL = "https://your-domain.com"
node build.mjs personal
Remove-Item Env:SITE_URL
```

Upload **nội dung** `dist/personal` lên static hosting có hỗ trợ `index.html` trong thư mục. Cấu hình domain ở hosting khi bạn sẵn sàng. Colab vẫn dùng URL nhập thủ công riêng.

`noindex` không phải mật khẩu: bản nháp đang chỉ chạy localhost. Nếu đưa lên mạng trước khi công khai, cần chế độ preview riêng của hosting. Không đưa token/API key vào cấu hình nội dung.

## Kiểm tra

```powershell
npm test
node build.mjs
# Khi server preview cổng 5178 đang mở và đã cài Playwright:
python browser_check.py
```

Đã kiểm tra hai kênh, escape nội dung, điều kiện công khai, URL, 6 route, không tràn ngang ở 390px và 1440px. Chưa kiểm tra hosting/domain thật.
