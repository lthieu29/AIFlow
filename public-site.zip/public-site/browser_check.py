"""Run after build + localhost preview server on port 5178."""
from pathlib import Path
from playwright.sync_api import sync_playwright, expect

screenshots = Path("../app/storage/verification/public-site")
screenshots.mkdir(parents=True, exist_ok=True)
with sync_playwright() as playwright:
    browser = playwright.chromium.launch(headless=True)
    page = browser.new_page(viewport={"width": 1440, "height": 1000})
    errors = []
    page.on("pageerror", lambda e: errors.append(str(e)))
    for path in ["/", "/about/", "/projects/", "/products/", "/articles/", "/contact/"]:
        response = page.goto("http://127.0.0.1:5178" + path)
        assert response.status == 200
        expect(page.locator("h1")).to_be_visible()
        assert page.locator('meta[name="robots"]').get_attribute("content") == "noindex,nofollow"
        if path == "/":
            page.screenshot(path=str(screenshots / "desktop.png"), full_page=True)
        page.set_viewport_size({"width": 390, "height": 844})
        assert page.evaluate("document.documentElement.scrollWidth <= innerWidth"), path
        if path == "/":
            page.screenshot(path=str(screenshots / "mobile.png"), full_page=True)
        page.set_viewport_size({"width": 1440, "height": 1000})
    assert not errors, errors
    browser.close()
    print("6 static routes, desktop/mobile, noindex, no horizontal overflow, no browser errors")
