import { readFile, writeFile, mkdir, copyFile, rm } from 'node:fs/promises';
import { resolve, dirname, extname, sep, relative } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = dirname(fileURLToPath(import.meta.url));
const escape = value => String(value ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const slug = value => typeof value === 'string' && /^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(value);
const external = value => { const url = new URL(value); if (url.protocol !== 'https:' || url.username || url.password) throw Error('Use an HTTPS public link without credentials.'); return url.href; };
const copy = {
  vi: { nav: ['Trang chủ', 'Giới thiệu', 'Dự án', 'Sản phẩm', 'Bài viết', 'Liên hệ'], draft: 'Bản nháp riêng. Nội dung chưa được công bố.', selected: 'Những dự án gần đây', empty: 'Nội dung đang được chuẩn bị.', contact: 'Giữ liên lạc', intro: 'Từ ý tưởng đến thành phẩm', more: 'Khám phá dự án', notes: 'Ghi chép & câu chuyện', pending: 'Kênh liên hệ sẽ được bổ sung trước khi công khai.', back: 'Về danh sách', skip: 'Đến nội dung' },
  en: { nav: ['Home', 'About', 'Projects', 'Products', 'Articles', 'Contact'], draft: 'Private draft. Content has not been published.', selected: 'Selected work', empty: 'New work is being prepared.', contact: 'Keep in touch', intro: 'From an idea to something real', more: 'Explore the work', notes: 'Notes & stories', pending: 'Contact details will be added before launch.', back: 'Back to collection', skip: 'Skip to content' }
};
const routes = ['', 'about', 'projects', 'products', 'articles', 'contact'];

export async function build(channels, destination = resolve(root, 'dist'), only = '') {
  for (const [id, config] of Object.entries(channels)) {
    if (only && only !== id) continue;
    if (!slug(id)) throw Error('Invalid channel slug.');
    const t = copy[config.language];
    if (!t || typeof config.draft !== 'boolean' || !config.name?.trim() || !config.headline?.trim()) throw Error(`Incomplete channel: ${id}`);
    if (config.email && !/^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/.test(config.email)) throw Error('Invalid email.');
    for (const link of config.links) external(link.url);
    let siteUrl = config.siteUrl ? external(config.siteUrl).replace(/\/$/, '') : '';
    if (siteUrl && (new URL(siteUrl).pathname !== '/' || new URL(siteUrl).search || new URL(siteUrl).hash)) throw Error('siteUrl must be an HTTPS origin.');
    if (!config.draft && (!siteUrl || !config.about?.trim() || (!config.email && !config.links.length))) throw Error(`Public release needs siteUrl, about and contact: ${id}`);
    const out = resolve(destination, id);
    if (relative(resolve(destination), out) !== id) throw Error('Output must be a direct channel folder.');
    // Only the verified generated channel folder is replaced, never source/assets.
    await rm(out, { recursive: true, force: true });
    await mkdir(out, { recursive: true });
    const entries = {};
    for (const kind of ['projects', 'products', 'articles']) {
      entries[kind] = config[kind] || [];
      const seen = new Set();
      for (const item of entries[kind]) {
        if (!slug(item.slug) || seen.has(item.slug) || !item.title?.trim()) throw Error(`Invalid or duplicate ${kind} slug.`);
        seen.add(item.slug);
        if (!config.draft && (!item.approved || !item.publicConsent)) throw Error('Approve content and public consent before release.');
        if (item.url) external(item.url);
        if (item.image) {
          if (!item.approved || !item.publicConsent || !item.alt?.trim()) throw Error('Images require approval, public consent and alt text, including in draft.');
          const asset = resolve(root, item.image);
          if (!asset.startsWith(resolve(root, 'assets') + sep) || !['.png', '.jpg', '.jpeg', '.webp'].includes(extname(asset).toLowerCase())) throw Error('Use a raster image inside public-site/assets.');
          const name = `${kind}-${item.slug}${extname(asset).toLowerCase()}`;
          await mkdir(resolve(out, 'assets'), { recursive: true });
          await copyFile(asset, resolve(out, 'assets', name));
        }
      }
    }
    const card = (item, kind) => `<a class="entry" href="/${kind}/${escape(item.slug)}/">${item.image ? `<img loading="lazy" src="/assets/${kind}-${escape(item.slug)}${extname(item.image).toLowerCase()}" alt="${escape(item.alt)}">` : ''}<span class="entry-kind">${escape(item.label || t.nav[routes.indexOf(kind)])}</span><h3>${escape(item.title)}</h3><p>${escape(item.summary)}</p><span aria-hidden="true">↗</span></a>`;
    const collection = kind => entries[kind].length ? `<div class="entries">${entries[kind].map(item => card(item, kind)).join('')}</div>` : `<p class="empty">${t.empty}</p>`;
    const contact = `<div class="contact">${config.email ? `<a class="cta" href="mailto:${escape(config.email)}">${escape(config.email)}</a>` : ''}${config.links.map(link => `<a class="contact-link" href="${escape(external(link.url))}" rel="noopener noreferrer">${escape(link.label)} ↗</a>`).join('')}${!config.email && !config.links.length ? `<p>${t.pending}</p>` : ''}</div>`;
    const pages = [
      ['', config.name, `<section class="hero"><p class="eyebrow">${t.intro}</p><h1>${escape(config.headline)}</h1><div class="hero-bottom"><p>${escape(config.description)}</p><a class="cta" href="/projects/">${t.more} ↗</a></div></section><section><div class="section-title"><h2>${t.selected}</h2></div>${collection('projects')}</section><section class="about-strip"><h2>${t.nav[1]}</h2><p>${escape(config.about)}</p><a href="/about/">${t.nav[1]} ↗</a></section><section><div class="section-title"><h2>${t.notes}</h2></div>${collection('articles')}</section>`],
      ['about', t.nav[1], `<section class="page-head"><p class="eyebrow">${escape(config.name)}</p><h1>${t.nav[1]}</h1><p class="prose">${escape(config.about)}</p></section>`],
      ...['projects', 'products', 'articles'].map(kind => [kind, t.nav[routes.indexOf(kind)], `<section class="page-head"><h1>${t.nav[routes.indexOf(kind)]}</h1>${collection(kind)}</section>`]),
      ['contact', t.nav[5], `<section class="page-head"><p class="eyebrow">${escape(config.name)}</p><h1>${t.contact}</h1>${contact}</section>`]
    ];
    for (const kind of ['projects', 'products', 'articles']) for (const item of entries[kind]) {
      pages.push([`${kind}/${item.slug}`, item.title, `<article class="page-head"><a href="/${kind}/">← ${t.back}</a><h1>${escape(item.title)}</h1><p class="standfirst">${escape(item.summary)}</p>${item.image ? `<img class="feature" src="/assets/${kind}-${escape(item.slug)}${extname(item.image).toLowerCase()}" alt="${escape(item.alt)}">` : ''}<div class="prose">${String(item.body || '').split(/\n\s*\n/).map(p => `<p>${escape(p)}</p>`).join('')}</div>${item.url ? `<a class="cta" href="${escape(external(item.url))}" rel="noopener noreferrer">${escape(item.linkLabel || item.title)} ↗</a>` : ''}</article>`]);
    }
    await copyFile(resolve(root, 'style.css'), resolve(out, 'style.css'));
    for (const [path, title, content] of pages) {
      const canonical = siteUrl ? `<link rel="canonical" href="${escape(siteUrl)}/${path ? `${escape(path)}/` : ''}">` : '';
      const html = `<!doctype html><html lang="${config.language}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>${escape(title)} · ${escape(config.name)}</title><meta name="description" content="${escape(config.description)}"><meta name="robots" content="${config.draft ? 'noindex,nofollow' : 'index,follow'}">${canonical}<link rel="stylesheet" href="/style.css"></head><body><a class="skip" href="#main">${t.skip}</a>${config.draft ? `<aside class="draft">${t.draft}</aside>` : ''}<header><a class="wordmark" href="/">${escape(config.name)}<span class="brand-dot" aria-hidden="true"></span></a><nav aria-label="Menu">${routes.map((route, n) => `<a ${path === route ? 'aria-current="page"' : ''} href="/${route ? route + '/' : ''}">${t.nav[n]}</a>`).join('')}</nav></header><main id="main">${content}</main><footer><span>${escape(config.name)}</span><a href="/contact/">${t.contact} ↗</a></footer></body></html>`;
      await mkdir(resolve(out, path), { recursive: true });
      await writeFile(resolve(out, path, 'index.html'), html);
    }
    await writeFile(resolve(out, 'robots.txt'), config.draft ? 'User-agent: *\nDisallow: /\n' : `User-agent: *\nAllow: /\nSitemap: ${siteUrl}/sitemap.xml\n`);
    await writeFile(resolve(out, 'sitemap.xml'), `<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${config.draft ? '' : pages.map(([path]) => `<url><loc>${escape(siteUrl)}/${path ? `${escape(path)}/` : ''}</loc></url>`).join('')}</urlset>`);
  }
  if (only && !channels[only]) throw Error(`Unknown channel: ${only}`);
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const channels = JSON.parse(await readFile(resolve(root, 'channels.json'), 'utf8'));
  const selected = process.argv[2] || '';
  if (process.env.SITE_URL) { if (!selected || !channels[selected]) throw Error('SITE_URL needs a valid channel argument.'); channels[selected].siteUrl = process.env.SITE_URL; }
  await build(channels, undefined, selected);
  console.log(`Built ${selected || Object.keys(channels).join(', ')}. Serve each dist/<channel> as its own site root.`);
}
