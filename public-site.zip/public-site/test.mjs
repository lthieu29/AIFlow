import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, readFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { build } from './build.mjs';

const draft = { name: 'Draft <studio>', draft: true, language: 'en', headline: 'In progress', about: 'A draft.', description: 'Draft', siteUrl: '', email: '', links: [], projects: [], products: [], articles: [] };
test('two independent channels, all routes, escaped content and noindex', async () => {
  const folder = await mkdtemp(join(tmpdir(), 'aiflow-site-'));
  try {
    await build({ one: structuredClone(draft), two: { ...structuredClone(draft), language: 'vi' } }, folder);
    for (const channel of ['one', 'two']) for (const path of ['', 'about', 'projects', 'products', 'articles', 'contact']) {
      const html = await readFile(join(folder, channel, path, 'index.html'), 'utf8');
      assert.ok(html.includes('noindex,nofollow'));
      assert.ok(html.includes('Draft &lt;studio&gt;'));
      assert.ok(!html.includes('/api/'));
    }
  } finally { await rm(folder, { recursive: true }); }
});
test('release needs identity/contact/origin and consent', async () => {
  const folder = await mkdtemp(join(tmpdir(), 'aiflow-site-'));
  try {
    await assert.rejects(build({ one: { ...draft, draft: false } }, folder));
    await assert.rejects(build({ one: { ...draft, links: [{ label: 'bad', url: 'javascript:alert(1)' }] } }, folder));
    await assert.rejects(build({ one: { ...draft, projects: [{ slug: 'pet', title: 'Pet', image: '../private.png' }] } }, folder));
    await assert.rejects(build({ one: { ...draft, draft: false, siteUrl: 'https://example.com', email: 'me@example.com', projects: [{ slug: 'pet', title: 'Pet' }] } }, folder));
    await build({ one: { ...draft, draft: false, siteUrl: 'https://example.com', email: 'me@example.com' } }, folder);
    assert.ok((await readFile(join(folder, 'one', 'sitemap.xml'), 'utf8')).includes('https://example.com/contact/'));
  } finally { await rm(folder, { recursive: true }); }
});
